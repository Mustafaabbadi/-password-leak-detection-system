from flask import Blueprint, jsonify, request, session
from datetime import datetime
from src.models.user import User, db
from src.services.breach_checker import BreachChecker
from src.services.password_manager import PasswordManager
from src.services.notification_service import NotificationService
from src.services.behavior_analyzer import BehaviorAnalyzer
from cryptography.fernet import Fernet
import os

user_bp = Blueprint('user', __name__)

# تهيئة الخدمات
breach_checker = BreachChecker()
password_manager = PasswordManager()
notification_service = NotificationService()
behavior_analyzer = BehaviorAnalyzer()

# مفتاح التشفير (يجب حفظه بشكل آمن في الإنتاج)
ENCRYPTION_KEY = Fernet.generate_key()
password_manager.set_encryption_key(ENCRYPTION_KEY)

@user_bp.route('/register', methods=['POST'])
def register():
    """تسجيل مستخدم جديد"""
    try:
        data = request.json
        
        # التحقق من البيانات المطلوبة
        if not data.get('username') or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'جميع الحقول مطلوبة'}), 400
        
        # التحقق من عدم وجود المستخدم مسبقاً
        existing_user = User.query.filter(
            (User.username == data['username']) | (User.email == data['email'])
        ).first()
        
        if existing_user:
            return jsonify({'error': 'اسم المستخدم أو البريد الإلكتروني موجود مسبقاً'}), 400
        
        # إنشاء المستخدم الجديد
        user = User(
            username=data['username'],
            email=data['email'],
            phone=data.get('phone'),
            telegram_chat_id=data.get('telegram_chat_id')
        )
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        # فحص البريد الإلكتروني للتسريبات
        breach_result = breach_checker.check_email_breach(user.email, user.id)
        
        return jsonify({
            'success': True,
            'message': 'تم إنشاء الحساب بنجاح',
            'user': user.to_dict(),
            'breach_check': breach_result
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في إنشاء الحساب: {str(e)}'}), 500

@user_bp.route('/login', methods=['POST'])
def login():
    """تسجيل الدخول"""
    try:
        data = request.json
        username_or_email = data.get('username_or_email')
        password = data.get('password')
        
        if not username_or_email or not password:
            return jsonify({'error': 'اسم المستخدم/البريد الإلكتروني وكلمة المرور مطلوبان'}), 400
        
        # البحث عن المستخدم
        user = User.query.filter(
            (User.username == username_or_email) | (User.email == username_or_email)
        ).first()
        
        # الحصول على معلومات الطلب
        ip_address = request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr)
        user_agent = request.headers.get('User-Agent', '')
        
        if user and user.check_password(password):
            # تسجيل دخول ناجح
            user.last_login = datetime.utcnow()
            session['user_id'] = user.id
            
            # تحليل السلوك
            behavior_result = behavior_analyzer.analyze_login_attempt(
                user.id, ip_address, user_agent, is_successful=True
            )
            
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'تم تسجيل الدخول بنجاح',
                'user': user.to_dict(),
                'behavior_analysis': behavior_result
            })
        else:
            # تسجيل دخول فاشل
            if user:
                behavior_analyzer.analyze_login_attempt(
                    user.id, ip_address, user_agent, is_successful=False
                )
                db.session.commit()
            
            return jsonify({'error': 'اسم المستخدم أو كلمة المرور غير صحيحة'}), 401
            
    except Exception as e:
        return jsonify({'error': f'خطأ في تسجيل الدخول: {str(e)}'}), 500

@user_bp.route('/logout', methods=['POST'])
def logout():
    """تسجيل الخروج"""
    session.pop('user_id', None)
    return jsonify({'success': True, 'message': 'تم تسجيل الخروج بنجاح'})

@user_bp.route('/profile', methods=['GET'])
def get_profile():
    """الحصول على ملف المستخدم الشخصي"""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'المستخدم غير موجود'}), 404
    
    # إحصائيات المستخدم
    stats = {
        'saved_passwords_count': len(user.saved_passwords),
        'alerts_count': len(user.alerts),
        'unread_alerts_count': len([alert for alert in user.alerts if not alert.is_read]),
        'breach_checks_count': len(user.breach_checks)
    }
    
    return jsonify({
        'user': user.to_dict(),
        'stats': stats
    })

@user_bp.route('/profile', methods=['PUT'])
def update_profile():
    """تحديث ملف المستخدم الشخصي"""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'المستخدم غير موجود'}), 404
    
    data = request.json
    
    # تحديث البيانات
    if 'username' in data:
        # التحقق من عدم وجود اسم المستخدم
        existing = User.query.filter(User.username == data['username'], User.id != user_id).first()
        if existing:
            return jsonify({'error': 'اسم المستخدم موجود مسبقاً'}), 400
        user.username = data['username']
    
    if 'email' in data:
        # التحقق من عدم وجود البريد الإلكتروني
        existing = User.query.filter(User.email == data['email'], User.id != user_id).first()
        if existing:
            return jsonify({'error': 'البريد الإلكتروني موجود مسبقاً'}), 400
        user.email = data['email']
    
    if 'phone' in data:
        user.phone = data['phone']
    
    if 'telegram_chat_id' in data:
        user.telegram_chat_id = data['telegram_chat_id']
    
    if 'notification_preferences' in data:
        user.notification_preferences = data['notification_preferences']
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'تم تحديث الملف الشخصي بنجاح',
        'user': user.to_dict()
    })

@user_bp.route('/change-password', methods=['POST'])
def change_password():
    """تغيير كلمة المرور"""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'المستخدم غير موجود'}), 404
    
    data = request.json
    current_password = data.get('current_password')
    new_password = data.get('new_password')
    
    if not current_password or not new_password:
        return jsonify({'error': 'كلمة المرور الحالية والجديدة مطلوبتان'}), 400
    
    # التحقق من كلمة المرور الحالية
    if not user.check_password(current_password):
        return jsonify({'error': 'كلمة المرور الحالية غير صحيحة'}), 400
    
    # فحص قوة كلمة المرور الجديدة
    strength = password_manager.evaluate_password_strength(new_password)
    if strength['score'] < 60:
        return jsonify({
            'error': 'كلمة المرور ضعيفة',
            'strength': strength
        }), 400
    
    # تحديث كلمة المرور
    user.set_password(new_password)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'تم تغيير كلمة المرور بنجاح',
        'strength': strength
    })

# المسارات الأصلية
@user_bp.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@user_bp.route('/users', methods=['POST'])
def create_user():
    data = request.json
    user = User(username=data['username'], email=data['email'])
    if 'password' in data:
        user.set_password(data['password'])
    db.session.add(user)
    db.session.commit()
    return jsonify(user.to_dict()), 201

@user_bp.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())

@user_bp.route('/users/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    user = User.query.get_or_404(user_id)
    data = request.json
    user.username = data.get('username', user.username)
    user.email = data.get('email', user.email)
    if 'phone' in data:
        user.phone = data['phone']
    db.session.commit()
    return jsonify(user.to_dict())

@user_bp.route('/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return '', 204
