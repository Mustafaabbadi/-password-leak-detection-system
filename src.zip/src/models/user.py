from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from cryptography.fernet import Fernet
import bcrypt
import os

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    password_hash = db.Column(db.String(128), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    telegram_chat_id = db.Column(db.String(50), nullable=True)
    notification_preferences = db.Column(db.JSON, default={'email': True, 'telegram': False, 'dashboard': True})
    
    # العلاقات
    saved_passwords = db.relationship('SavedPassword', backref='user', lazy=True, cascade='all, delete-orphan')
    login_logs = db.relationship('LoginLog', backref='user', lazy=True, cascade='all, delete-orphan')
    alerts = db.relationship('Alert', backref='user', lazy=True, cascade='all, delete-orphan')
    breach_checks = db.relationship('BreachCheck', backref='user', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<User {self.username}>'

    def set_password(self, password):
        """تشفير كلمة المرور وحفظها"""
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    def check_password(self, password):
        """التحقق من كلمة المرور"""
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'phone': self.phone,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'is_active': self.is_active,
            'notification_preferences': self.notification_preferences
        }

class SavedPassword(db.Model):
    """نموذج لحفظ كلمات المرور المشفرة"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    website_name = db.Column(db.String(100), nullable=False)
    website_url = db.Column(db.String(255), nullable=True)
    username = db.Column(db.String(100), nullable=False)
    encrypted_password = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)
    last_check_date = db.Column(db.DateTime, nullable=True)
    is_compromised = db.Column(db.Boolean, default=False)
    
    def encrypt_password(self, password, key):
        """تشفير كلمة المرور باستخدام AES-256"""
        f = Fernet(key)
        self.encrypted_password = f.encrypt(password.encode()).decode()
    
    def decrypt_password(self, key):
        """فك تشفير كلمة المرور"""
        f = Fernet(key)
        return f.decrypt(self.encrypted_password.encode()).decode()
    
    def to_dict(self):
        return {
            'id': self.id,
            'website_name': self.website_name,
            'website_url': self.website_url,
            'username': self.username,
            'created_at': self.created_at.isoformat(),
            'last_updated': self.last_updated.isoformat(),
            'last_check_date': self.last_check_date.isoformat() if self.last_check_date else None,
            'is_compromised': self.is_compromised
        }

class LoginLog(db.Model):
    """سجل تسجيل الدخول لتحليل السلوك"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    login_time = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(45), nullable=False)
    user_agent = db.Column(db.Text, nullable=True)
    location_country = db.Column(db.String(50), nullable=True)
    location_city = db.Column(db.String(100), nullable=True)
    is_successful = db.Column(db.Boolean, default=True)
    is_suspicious = db.Column(db.Boolean, default=False)
    risk_score = db.Column(db.Float, default=0.0)
    
    def to_dict(self):
        return {
            'id': self.id,
            'login_time': self.login_time.isoformat(),
            'ip_address': self.ip_address,
            'location_country': self.location_country,
            'location_city': self.location_city,
            'is_successful': self.is_successful,
            'is_suspicious': self.is_suspicious,
            'risk_score': self.risk_score
        }

class Alert(db.Model):
    """نموذج التنبيهات"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    alert_type = db.Column(db.String(50), nullable=False)  # 'breach', 'suspicious_login', 'password_weak'
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    severity = db.Column(db.String(20), default='medium')  # 'low', 'medium', 'high', 'critical'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)
    is_resolved = db.Column(db.Boolean, default=False)
    alert_metadata = db.Column(db.JSON, nullable=True)  # معلومات إضافية حسب نوع التنبيه
    
    def to_dict(self):
        return {
            'id': self.id,
            'alert_type': self.alert_type,
            'title': self.title,
            'message': self.message,
            'severity': self.severity,
            'created_at': self.created_at.isoformat(),
            'is_read': self.is_read,
            'is_resolved': self.is_resolved,
            'metadata': self.alert_metadata
        }

class BreachCheck(db.Model):
    """سجل فحص التسريبات"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    email_or_username = db.Column(db.String(255), nullable=False)
    check_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_breached = db.Column(db.Boolean, default=False)
    breach_count = db.Column(db.Integer, default=0)
    breach_details = db.Column(db.JSON, nullable=True)  # تفاصيل التسريبات المكتشفة
    
    def to_dict(self):
        return {
            'id': self.id,
            'email_or_username': self.email_or_username,
            'check_date': self.check_date.isoformat(),
            'is_breached': self.is_breached,
            'breach_count': self.breach_count,
            'breach_details': self.breach_details
        }

class SystemSettings(db.Model):
    """إعدادات النظام العامة"""
    id = db.Column(db.Integer, primary_key=True)
    setting_key = db.Column(db.String(100), unique=True, nullable=False)
    setting_value = db.Column(db.Text, nullable=True)
    description = db.Column(db.Text, nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'setting_key': self.setting_key,
            'setting_value': self.setting_value,
            'description': self.description,
            'updated_at': self.updated_at.isoformat()
        }
