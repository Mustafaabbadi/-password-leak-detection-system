from flask import Blueprint, jsonify, request, session
from src.models.user import User, db
from src.services.breach_checker import BreachChecker
from src.services.notification_service import NotificationService
from src.services.behavior_analyzer import BehaviorAnalyzer

security_bp = Blueprint('security', __name__)

# تهيئة الخدمات
breach_checker = BreachChecker()
notification_service = NotificationService()
behavior_analyzer = BehaviorAnalyzer()

def require_login():
    """التحقق من تسجيل الدخول"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    return User.query.get(user_id)

@security_bp.route('/check-email', methods=['POST'])
def check_email_breach():
    """فحص البريد الإلكتروني للتسريبات"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    data = request.json
    email = data.get('email', user.email)
    
    if not email:
        return jsonify({'error': 'البريد الإلكتروني مطلوب'}), 400
    
    result = breach_checker.check_email_breach(email, user.id)
    return jsonify(result)

@security_bp.route('/breach-history', methods=['GET'])
def get_breach_history():
    """الحصول على تاريخ فحص التسريبات"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    history = breach_checker.get_user_breach_history(user.id)
    return jsonify({'breach_history': history})

@security_bp.route('/alerts', methods=['GET'])
def get_alerts():
    """الحصول على تنبيهات المستخدم"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    limit = request.args.get('limit', 50, type=int)
    unread_only = request.args.get('unread_only', False, type=bool)
    
    alerts = notification_service.get_user_alerts(user.id, limit, unread_only)
    return jsonify({'alerts': alerts})

@security_bp.route('/alerts/<int:alert_id>/read', methods=['POST'])
def mark_alert_read(alert_id):
    """تحديد التنبيه كمقروء"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    result = notification_service.mark_alert_as_read(user.id, alert_id)
    return jsonify(result)

@security_bp.route('/alerts/<int:alert_id>/resolve', methods=['POST'])
def mark_alert_resolved(alert_id):
    """تحديد التنبيه كمحلول"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    result = notification_service.mark_alert_as_resolved(user.id, alert_id)
    return jsonify(result)

@security_bp.route('/alerts/stats', methods=['GET'])
def get_alert_stats():
    """إحصائيات التنبيهات"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    stats = notification_service.get_notification_stats(user.id)
    return jsonify(stats)

@security_bp.route('/behavior/stats', methods=['GET'])
def get_behavior_stats():
    """إحصائيات سلوك المستخدم"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    stats = behavior_analyzer.get_user_behavior_stats(user.id)
    return jsonify(stats)

@security_bp.route('/behavior/train', methods=['POST'])
def train_behavior_model():
    """تدريب نموذج تحليل السلوك"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    # تدريب النموذج للمستخدم الحالي أو لجميع المستخدمين
    train_for_user = request.json.get('user_specific', True)
    user_id = user.id if train_for_user else None
    
    result = behavior_analyzer.train_ml_model(user_id)
    return jsonify(result)

@security_bp.route('/dashboard', methods=['GET'])
def get_security_dashboard():
    """لوحة تحكم الأمان الشاملة"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    # إحصائيات التنبيهات
    alert_stats = notification_service.get_notification_stats(user.id)
    
    # إحصائيات السلوك
    behavior_stats = behavior_analyzer.get_user_behavior_stats(user.id)
    
    # آخر التنبيهات
    recent_alerts = notification_service.get_user_alerts(user.id, limit=5)
    
    # تاريخ فحص التسريبات
    breach_history = breach_checker.get_user_breach_history(user.id)
    recent_breaches = breach_history[:5] if breach_history else []
    
    # حساب النقاط الأمنية العامة
    security_score = calculate_security_score(user, alert_stats, behavior_stats)
    
    return jsonify({
        'user': user.to_dict(),
        'security_score': security_score,
        'alert_stats': alert_stats,
        'behavior_stats': behavior_stats,
        'recent_alerts': recent_alerts,
        'recent_breaches': recent_breaches,
        'recommendations': generate_security_recommendations(user, alert_stats, behavior_stats)
    })

@security_bp.route('/test-notification', methods=['POST'])
def test_notification():
    """اختبار إرسال التنبيهات"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    data = request.json
    notification_type = data.get('type', 'email')  # email, telegram, dashboard
    
    # إنشاء تنبيه تجريبي
    from src.models.user import Alert
    test_alert = Alert(
        user_id=user.id,
        alert_type='test',
        title='تنبيه تجريبي',
        message='هذا تنبيه تجريبي للتأكد من عمل نظام التنبيهات بشكل صحيح.',
        severity='low',
        alert_metadata={'test': True}
    )
    
    db.session.add(test_alert)
    db.session.flush()  # للحصول على ID التنبيه
    
    # إرسال التنبيه
    result = notification_service.send_notification(user.id, test_alert)
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'تم إرسال التنبيه التجريبي',
        'result': result
    })

def calculate_security_score(user, alert_stats, behavior_stats):
    """حساب النقاط الأمنية العامة للمستخدم"""
    score = 100  # البداية بنقاط كاملة
    
    # خصم نقاط للتنبيهات غير المقروءة
    unread_alerts = alert_stats.get('unread_alerts', 0)
    score -= min(unread_alerts * 5, 30)  # حد أقصى 30 نقطة خصم
    
    # خصم نقاط للتنبيهات الحرجة
    critical_alerts = alert_stats.get('critical_alerts', 0)
    score -= min(critical_alerts * 10, 40)  # حد أقصى 40 نقطة خصم
    
    # خصم نقاط للنشاط المشبوه
    if isinstance(behavior_stats, dict):
        suspicious_logins = behavior_stats.get('suspicious_logins', 0)
        total_logins = behavior_stats.get('total_logins', 1)
        suspicious_ratio = suspicious_logins / total_logins if total_logins > 0 else 0
        score -= min(suspicious_ratio * 50, 25)  # حد أقصى 25 نقطة خصم
    
    # التأكد من أن النقاط لا تقل عن 0
    return max(0, min(100, score))

def generate_security_recommendations(user, alert_stats, behavior_stats):
    """توليد توصيات أمنية للمستخدم"""
    recommendations = []
    
    # توصيات بناءً على التنبيهات
    unread_alerts = alert_stats.get('unread_alerts', 0)
    if unread_alerts > 0:
        recommendations.append({
            'type': 'alerts',
            'priority': 'high',
            'title': 'مراجعة التنبيهات',
            'description': f'لديك {unread_alerts} تنبيه(ات) غير مقروءة. يرجى مراجعتها واتخاذ الإجراءات اللازمة.'
        })
    
    critical_alerts = alert_stats.get('critical_alerts', 0)
    if critical_alerts > 0:
        recommendations.append({
            'type': 'security',
            'priority': 'critical',
            'title': 'تنبيهات حرجة',
            'description': f'لديك {critical_alerts} تنبيه(ات) حرجة تتطلب اهتماماً فورياً.'
        })
    
    # توصيات بناءً على السلوك
    if isinstance(behavior_stats, dict):
        success_rate = behavior_stats.get('success_rate', 1)
        if success_rate < 0.9:
            recommendations.append({
                'type': 'behavior',
                'priority': 'medium',
                'title': 'تحسين أمان تسجيل الدخول',
                'description': 'معدل نجاح تسجيل الدخول منخفض. تأكد من استخدام كلمات مرور قوية وفعّل المصادقة الثنائية.'
            })
        
        suspicious_logins = behavior_stats.get('suspicious_logins', 0)
        if suspicious_logins > 0:
            recommendations.append({
                'type': 'behavior',
                'priority': 'high',
                'title': 'نشاط مشبوه مكتشف',
                'description': f'تم اكتشاف {suspicious_logins} محاولة(ات) تسجيل دخول مشبوهة. راجع سجل النشاط وغيّر كلمة المرور إذا لزم الأمر.'
            })
    
    # توصيات عامة
    if not recommendations:
        recommendations.append({
            'type': 'general',
            'priority': 'low',
            'title': 'حالة أمنية جيدة',
            'description': 'حسابك في حالة أمنية جيدة. استمر في اتباع أفضل الممارسات الأمنية.'
        })
    
    return recommendations

