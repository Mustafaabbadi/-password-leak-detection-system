from flask import Blueprint, jsonify, request, session
from src.models.user import User, db
from src.services.password_manager import PasswordManager
from src.services.breach_checker import BreachChecker
from cryptography.fernet import Fernet

passwords_bp = Blueprint('passwords', __name__)

# تهيئة الخدمات
password_manager = PasswordManager()
breach_checker = BreachChecker()

# مفتاح التشفير (يجب أن يكون نفس المفتاح المستخدم في user.py)
ENCRYPTION_KEY = Fernet.generate_key()
password_manager.set_encryption_key(ENCRYPTION_KEY)

def require_login():
    """التحقق من تسجيل الدخول"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    return User.query.get(user_id)

@passwords_bp.route('/generate', methods=['POST'])
def generate_password():
    """توليد كلمة مرور قوية"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    data = request.json or {}
    
    # معاملات توليد كلمة المرور
    length = data.get('length', 16)
    include_uppercase = data.get('include_uppercase', True)
    include_lowercase = data.get('include_lowercase', True)
    include_numbers = data.get('include_numbers', True)
    include_symbols = data.get('include_symbols', True)
    exclude_ambiguous = data.get('exclude_ambiguous', True)
    
    # توليد كلمة المرور
    result = password_manager.generate_strong_password(
        length=length,
        include_uppercase=include_uppercase,
        include_lowercase=include_lowercase,
        include_numbers=include_numbers,
        include_symbols=include_symbols,
        exclude_ambiguous=exclude_ambiguous
    )
    
    if result['success']:
        # فحص كلمة المرور في قاعدة بيانات التسريبات
        breach_result = breach_checker.check_password_hash(result['password'])
        result['breach_check'] = breach_result
    
    return jsonify(result)

@passwords_bp.route('/evaluate', methods=['POST'])
def evaluate_password():
    """تقييم قوة كلمة المرور"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    data = request.json
    password = data.get('password')
    
    if not password:
        return jsonify({'error': 'كلمة المرور مطلوبة'}), 400
    
    # تقييم قوة كلمة المرور
    strength = password_manager.evaluate_password_strength(password)
    
    # فحص كلمة المرور في قاعدة بيانات التسريبات
    breach_result = breach_checker.check_password_hash(password)
    
    return jsonify({
        'strength': strength,
        'breach_check': breach_result
    })

@passwords_bp.route('/save', methods=['POST'])
def save_password():
    """حفظ كلمة مرور مشفرة"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    data = request.json
    website_name = data.get('website_name')
    website_url = data.get('website_url', '')
    username = data.get('username')
    password = data.get('password')
    
    if not website_name or not username or not password:
        return jsonify({'error': 'اسم الموقع واسم المستخدم وكلمة المرور مطلوبة'}), 400
    
    # حفظ كلمة المرور
    result = password_manager.save_password(
        user_id=user.id,
        website_name=website_name,
        website_url=website_url,
        username=username,
        password=password
    )
    
    return jsonify(result)

@passwords_bp.route('/list', methods=['GET'])
def list_passwords():
    """قائمة كلمات المرور المحفوظة"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    passwords = password_manager.get_saved_passwords(user.id)
    return jsonify({'passwords': passwords})

@passwords_bp.route('/<int:password_id>', methods=['GET'])
def get_password(password_id):
    """الحصول على كلمة مرور محددة (مفكوكة التشفير)"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    result = password_manager.get_password(user.id, password_id)
    return jsonify(result)

@passwords_bp.route('/<int:password_id>', methods=['PUT'])
def update_password(password_id):
    """تحديث كلمة مرور محفوظة"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    data = request.json
    new_password = data.get('new_password')
    
    if not new_password:
        return jsonify({'error': 'كلمة المرور الجديدة مطلوبة'}), 400
    
    result = password_manager.update_password(user.id, password_id, new_password)
    return jsonify(result)

@passwords_bp.route('/<int:password_id>', methods=['DELETE'])
def delete_password(password_id):
    """حذف كلمة مرور محفوظة"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    result = password_manager.delete_password(user.id, password_id)
    return jsonify(result)

@passwords_bp.route('/check-expiry', methods=['GET'])
def check_password_expiry():
    """فحص كلمات المرور المنتهية الصلاحية"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    expired_passwords = password_manager.check_password_expiry(user.id)
    return jsonify({'expired_passwords': expired_passwords})

@passwords_bp.route('/bulk-check', methods=['POST'])
def bulk_check_passwords():
    """فحص جماعي لكلمات المرور المحفوظة"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    # الحصول على جميع كلمات المرور المحفوظة
    saved_passwords = password_manager.get_saved_passwords(user.id)
    
    results = []
    for saved_password in saved_passwords:
        # الحصول على كلمة المرور المفكوكة التشفير
        password_data = password_manager.get_password(user.id, saved_password['id'])
        
        if password_data['success']:
            # فحص كلمة المرور في قاعدة بيانات التسريبات
            breach_result = breach_checker.check_password_hash(password_data['password'])
            
            results.append({
                'password_id': saved_password['id'],
                'website_name': saved_password['website_name'],
                'username': saved_password['username'],
                'breach_check': breach_result,
                'last_updated': saved_password['last_updated']
            })
    
    return jsonify({
        'success': True,
        'total_checked': len(results),
        'results': results
    })

@passwords_bp.route('/stats', methods=['GET'])
def get_password_stats():
    """إحصائيات كلمات المرور للمستخدم"""
    user = require_login()
    if not user:
        return jsonify({'error': 'يجب تسجيل الدخول أولاً'}), 401
    
    saved_passwords = password_manager.get_saved_passwords(user.id)
    
    # حساب الإحصائيات
    total_passwords = len(saved_passwords)
    compromised_passwords = len([p for p in saved_passwords if p.get('is_compromised', False)])
    
    # فحص كلمات المرور المنتهية الصلاحية
    expired_passwords = password_manager.check_password_expiry(user.id)
    expired_count = len(expired_passwords)
    
    return jsonify({
        'total_passwords': total_passwords,
        'compromised_passwords': compromised_passwords,
        'expired_passwords': expired_count,
        'secure_passwords': total_passwords - compromised_passwords - expired_count,
        'security_score': ((total_passwords - compromised_passwords - expired_count) / total_passwords * 100) if total_passwords > 0 else 100
    })

