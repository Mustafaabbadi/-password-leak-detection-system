import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.routes.user import user_bp
from src.routes.passwords import passwords_bp
from src.routes.security import security_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))

# إعدادات التطبيق
app.config['SECRET_KEY'] = 'password-leak-detection-system-secret-key-2024'
app.config['SESSION_COOKIE_SECURE'] = False  # True في الإنتاج مع HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# تفعيل CORS للسماح بالطلبات من الواجهة الأمامية
CORS(app, supports_credentials=True)

# تسجيل المسارات
app.register_blueprint(user_bp, url_prefix='/api/users')
app.register_blueprint(passwords_bp, url_prefix='/api/passwords')
app.register_blueprint(security_bp, url_prefix='/api/security')

# إعدادات قاعدة البيانات
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# إنشاء الجداول
with app.app_context():
    db.create_all()
    
    # إضافة بيانات تجريبية إذا لم تكن موجودة
    from src.models.user import User, SystemSettings
    
    # إضافة إعدادات النظام الافتراضية
    if not SystemSettings.query.filter_by(setting_key='developer_phone').first():
        developer_settings = [
            SystemSettings(
                setting_key='developer_phone',
                setting_value='0592774301',
                description='رقم هاتف المطور'
            ),
            SystemSettings(
                setting_key='developer_email',
                setting_value='mabbadi0@icloud.com',
                description='البريد الإلكتروني للمطور'
            ),
            SystemSettings(
                setting_key='system_name',
                setting_value='نظام كشف تسريب كلمات المرور الذكي',
                description='اسم النظام'
            ),
            SystemSettings(
                setting_key='version',
                setting_value='1.0.0',
                description='إصدار النظام'
            )
        ]
        
        for setting in developer_settings:
            db.session.add(setting)
        
        db.session.commit()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            # إرجاع صفحة ترحيب بسيطة إذا لم توجد index.html
            return """
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>نظام كشف تسريب كلمات المرور الذكي</title>
                <style>
                    body {
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        margin: 0;
                        padding: 20px;
                        min-height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    .container {
                        background: white;
                        padding: 40px;
                        border-radius: 15px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                        text-align: center;
                        max-width: 600px;
                    }
                    h1 {
                        color: #333;
                        margin-bottom: 20px;
                    }
                    .api-info {
                        background: #f8f9fa;
                        padding: 20px;
                        border-radius: 10px;
                        margin: 20px 0;
                        text-align: right;
                    }
                    .endpoint {
                        background: #e9ecef;
                        padding: 10px;
                        margin: 10px 0;
                        border-radius: 5px;
                        font-family: monospace;
                    }
                    .developer-info {
                        background: #d4edda;
                        border: 1px solid #c3e6cb;
                        padding: 15px;
                        border-radius: 8px;
                        margin-top: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>🔒 نظام كشف تسريب كلمات المرور الذكي</h1>
                    <p>مرحباً بك في النظام الذكي للكشف المبكر عن تسريب كلمات المرور</p>
                    
                    <div class="api-info">
                        <h3>واجهات برمجة التطبيقات المتاحة:</h3>
                        
                        <h4>إدارة المستخدمين:</h4>
                        <div class="endpoint">POST /api/users/register - تسجيل مستخدم جديد</div>
                        <div class="endpoint">POST /api/users/login - تسجيل الدخول</div>
                        <div class="endpoint">POST /api/users/logout - تسجيل الخروج</div>
                        <div class="endpoint">GET /api/users/profile - الملف الشخصي</div>
                        
                        <h4>إدارة كلمات المرور:</h4>
                        <div class="endpoint">POST /api/passwords/generate - توليد كلمة مرور قوية</div>
                        <div class="endpoint">POST /api/passwords/evaluate - تقييم قوة كلمة المرور</div>
                        <div class="endpoint">POST /api/passwords/save - حفظ كلمة مرور</div>
                        <div class="endpoint">GET /api/passwords/list - قائمة كلمات المرور</div>
                        
                        <h4>الأمان والتنبيهات:</h4>
                        <div class="endpoint">POST /api/security/check-email - فحص البريد للتسريبات</div>
                        <div class="endpoint">GET /api/security/alerts - التنبيهات</div>
                        <div class="endpoint">GET /api/security/dashboard - لوحة التحكم</div>
                    </div>
                    
                    <div class="developer-info">
                        <h4>معلومات المطور:</h4>
                        <p><strong>الهاتف:</strong> 0592774301</p>
                        <p><strong>البريد الإلكتروني:</strong> mabbadi0@icloud.com</p>
                        <p><strong>الإصدار:</strong> 1.0.0</p>
                    </div>
                </div>
            </body>
            </html>
            """

# مسار للحصول على معلومات النظام
@app.route('/api/system/info', methods=['GET'])
def get_system_info():
    """معلومات النظام"""
    from src.models.user import SystemSettings
    
    settings = SystemSettings.query.all()
    system_info = {setting.setting_key: setting.setting_value for setting in settings}
    
    return {
        'system_name': system_info.get('system_name', 'نظام كشف تسريب كلمات المرور الذكي'),
        'version': system_info.get('version', '1.0.0'),
        'developer': {
            'phone': system_info.get('developer_phone', '0592774301'),
            'email': system_info.get('developer_email', 'mabbadi0@icloud.com')
        },
        'features': [
            'كشف تسريب كلمات المرور',
            'تحليل السلوك بالذكاء الاصطناعي',
            'تنبيهات ذكية وفورية',
            'مولد كلمات مرور آمن',
            'لوحة تحكم شاملة'
        ]
    }

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
