import secrets
import string
import re
from typing import Dict, List, Optional
from cryptography.fernet import Fernet
from datetime import datetime, timedelta
from src.models.user import db, SavedPassword, Alert

class PasswordManager:
    """مولد ومدير كلمات المرور الآمن"""
    
    def __init__(self):
        self.encryption_key = None
    
    def generate_encryption_key(self) -> bytes:
        """توليد مفتاح تشفير جديد"""
        return Fernet.generate_key()
    
    def set_encryption_key(self, key: bytes):
        """تعيين مفتاح التشفير"""
        self.encryption_key = key
    
    def generate_strong_password(self, 
                                length: int = 16, 
                                include_uppercase: bool = True,
                                include_lowercase: bool = True, 
                                include_numbers: bool = True,
                                include_symbols: bool = True,
                                exclude_ambiguous: bool = True) -> Dict:
        """توليد كلمة مرور قوية حسب معايير OWASP"""
        
        if length < 8:
            return {
                'success': False,
                'error': 'طول كلمة المرور يجب أن يكون 8 أحرف على الأقل'
            }
        
        # تحديد الأحرف المتاحة
        characters = ""
        
        if include_lowercase:
            chars = string.ascii_lowercase
            if exclude_ambiguous:
                chars = chars.replace('l', '').replace('o', '')
            characters += chars
        
        if include_uppercase:
            chars = string.ascii_uppercase
            if exclude_ambiguous:
                chars = chars.replace('I', '').replace('O', '')
            characters += chars
        
        if include_numbers:
            chars = string.digits
            if exclude_ambiguous:
                chars = chars.replace('0', '').replace('1', '')
            characters += chars
        
        if include_symbols:
            chars = "!@#$%^&*()_+-=[]{}|;:,.<>?"
            if exclude_ambiguous:
                chars = chars.replace('|', '').replace('l', '')
            characters += chars
        
        if not characters:
            return {
                'success': False,
                'error': 'يجب تحديد نوع واحد على الأقل من الأحرف'
            }
        
        # توليد كلمة المرور
        password = ''.join(secrets.choice(characters) for _ in range(length))
        
        # التأكد من وجود جميع أنواع الأحرف المطلوبة
        password = self._ensure_character_types(password, include_uppercase, 
                                              include_lowercase, include_numbers, 
                                              include_symbols, exclude_ambiguous)
        
        # تقييم قوة كلمة المرور
        strength = self.evaluate_password_strength(password)
        
        return {
            'success': True,
            'password': password,
            'strength': strength,
            'length': len(password)
        }
    
    def _ensure_character_types(self, password: str, uppercase: bool, 
                               lowercase: bool, numbers: bool, symbols: bool,
                               exclude_ambiguous: bool) -> str:
        """التأكد من وجود جميع أنواع الأحرف المطلوبة"""
        password_list = list(password)
        
        # قوائم الأحرف
        lower_chars = string.ascii_lowercase
        upper_chars = string.ascii_uppercase
        number_chars = string.digits
        symbol_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?"
        
        if exclude_ambiguous:
            lower_chars = lower_chars.replace('l', '').replace('o', '')
            upper_chars = upper_chars.replace('I', '').replace('O', '')
            number_chars = number_chars.replace('0', '').replace('1', '')
            symbol_chars = symbol_chars.replace('|', '').replace('l', '')
        
        # التحقق من وجود كل نوع مطلوب
        if lowercase and not any(c in lower_chars for c in password):
            password_list[0] = secrets.choice(lower_chars)
        
        if uppercase and not any(c in upper_chars for c in password):
            password_list[1] = secrets.choice(upper_chars)
        
        if numbers and not any(c in number_chars for c in password):
            password_list[2] = secrets.choice(number_chars)
        
        if symbols and not any(c in symbol_chars for c in password):
            password_list[3] = secrets.choice(symbol_chars)
        
        # خلط الأحرف
        secrets.SystemRandom().shuffle(password_list)
        
        return ''.join(password_list)
    
    def evaluate_password_strength(self, password: str) -> Dict:
        """تقييم قوة كلمة المرور"""
        score = 0
        feedback = []
        
        # طول كلمة المرور
        length = len(password)
        if length >= 12:
            score += 25
        elif length >= 8:
            score += 15
            feedback.append("استخدم 12 حرف أو أكثر لمزيد من الأمان")
        else:
            score += 5
            feedback.append("كلمة المرور قصيرة جداً")
        
        # تنوع الأحرف
        has_lower = bool(re.search(r'[a-z]', password))
        has_upper = bool(re.search(r'[A-Z]', password))
        has_digit = bool(re.search(r'\d', password))
        has_symbol = bool(re.search(r'[!@#$%^&*()_+\-=\[\]{}|;:,.<>?]', password))
        
        char_types = sum([has_lower, has_upper, has_digit, has_symbol])
        score += char_types * 15
        
        if char_types < 3:
            feedback.append("استخدم مزيج من الأحرف الكبيرة والصغيرة والأرقام والرموز")
        
        # تجنب الأنماط الشائعة
        if re.search(r'(.)\1{2,}', password):  # تكرار الأحرف
            score -= 10
            feedback.append("تجنب تكرار الأحرف")
        
        if re.search(r'(012|123|234|345|456|567|678|789|890)', password):
            score -= 15
            feedback.append("تجنب التسلسل الرقمي")
        
        if re.search(r'(abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz)', password.lower()):
            score -= 15
            feedback.append("تجنب التسلسل الأبجدي")
        
        # تحديد مستوى القوة
        if score >= 80:
            strength_level = "قوية جداً"
            color = "green"
        elif score >= 60:
            strength_level = "قوية"
            color = "lightgreen"
        elif score >= 40:
            strength_level = "متوسطة"
            color = "orange"
        elif score >= 20:
            strength_level = "ضعيفة"
            color = "red"
        else:
            strength_level = "ضعيفة جداً"
            color = "darkred"
        
        return {
            'score': min(100, max(0, score)),
            'level': strength_level,
            'color': color,
            'feedback': feedback,
            'has_lowercase': has_lower,
            'has_uppercase': has_upper,
            'has_numbers': has_digit,
            'has_symbols': has_symbol,
            'length': length
        }
    
    def save_password(self, user_id: int, website_name: str, website_url: str,
                     username: str, password: str) -> Dict:
        """حفظ كلمة مرور مشفرة"""
        try:
            if not self.encryption_key:
                return {
                    'success': False,
                    'error': 'مفتاح التشفير غير محدد'
                }
            
            # إنشاء سجل كلمة مرور جديد
            saved_password = SavedPassword(
                user_id=user_id,
                website_name=website_name,
                website_url=website_url,
                username=username
            )
            
            # تشفير كلمة المرور
            saved_password.encrypt_password(password, self.encryption_key)
            
            db.session.add(saved_password)
            db.session.commit()
            
            return {
                'success': True,
                'message': 'تم حفظ كلمة المرور بنجاح',
                'password_id': saved_password.id
            }
            
        except Exception as e:
            db.session.rollback()
            return {
                'success': False,
                'error': f'خطأ في حفظ كلمة المرور: {str(e)}'
            }
    
    def get_saved_passwords(self, user_id: int) -> List[Dict]:
        """الحصول على كلمات المرور المحفوظة للمستخدم"""
        passwords = SavedPassword.query.filter_by(user_id=user_id).order_by(SavedPassword.created_at.desc()).all()
        return [password.to_dict() for password in passwords]
    
    def get_password(self, user_id: int, password_id: int) -> Dict:
        """الحصول على كلمة مرور محددة (مفكوكة التشفير)"""
        try:
            password_record = SavedPassword.query.filter_by(
                id=password_id, 
                user_id=user_id
            ).first()
            
            if not password_record:
                return {
                    'success': False,
                    'error': 'كلمة المرور غير موجودة'
                }
            
            if not self.encryption_key:
                return {
                    'success': False,
                    'error': 'مفتاح التشفير غير محدد'
                }
            
            # فك تشفير كلمة المرور
            decrypted_password = password_record.decrypt_password(self.encryption_key)
            
            result = password_record.to_dict()
            result['password'] = decrypted_password
            result['success'] = True
            
            return result
            
        except Exception as e:
            return {
                'success': False,
                'error': f'خطأ في استرجاع كلمة المرور: {str(e)}'
            }
    
    def update_password(self, user_id: int, password_id: int, new_password: str) -> Dict:
        """تحديث كلمة مرور محفوظة"""
        try:
            password_record = SavedPassword.query.filter_by(
                id=password_id, 
                user_id=user_id
            ).first()
            
            if not password_record:
                return {
                    'success': False,
                    'error': 'كلمة المرور غير موجودة'
                }
            
            if not self.encryption_key:
                return {
                    'success': False,
                    'error': 'مفتاح التشفير غير محدد'
                }
            
            # تشفير كلمة المرور الجديدة
            password_record.encrypt_password(new_password, self.encryption_key)
            password_record.last_updated = datetime.utcnow()
            
            db.session.commit()
            
            return {
                'success': True,
                'message': 'تم تحديث كلمة المرور بنجاح'
            }
            
        except Exception as e:
            db.session.rollback()
            return {
                'success': False,
                'error': f'خطأ في تحديث كلمة المرور: {str(e)}'
            }
    
    def delete_password(self, user_id: int, password_id: int) -> Dict:
        """حذف كلمة مرور محفوظة"""
        try:
            password_record = SavedPassword.query.filter_by(
                id=password_id, 
                user_id=user_id
            ).first()
            
            if not password_record:
                return {
                    'success': False,
                    'error': 'كلمة المرور غير موجودة'
                }
            
            db.session.delete(password_record)
            db.session.commit()
            
            return {
                'success': True,
                'message': 'تم حذف كلمة المرور بنجاح'
            }
            
        except Exception as e:
            db.session.rollback()
            return {
                'success': False,
                'error': f'خطأ في حذف كلمة المرور: {str(e)}'
            }
    
    def check_password_expiry(self, user_id: int) -> List[Dict]:
        """فحص كلمات المرور المنتهية الصلاحية"""
        expiry_days = 90  # تغيير كلمة المرور كل 90 يوم
        expiry_date = datetime.utcnow() - timedelta(days=expiry_days)
        
        expired_passwords = SavedPassword.query.filter(
            SavedPassword.user_id == user_id,
            SavedPassword.last_updated < expiry_date
        ).all()
        
        # إنشاء تنبيهات للكلمات المنتهية الصلاحية
        for password in expired_passwords:
            self._create_expiry_alert(user_id, password)
        
        return [password.to_dict() for password in expired_passwords]
    
    def _create_expiry_alert(self, user_id: int, password_record: SavedPassword):
        """إنشاء تنبيه لكلمة مرور منتهية الصلاحية"""
        days_old = (datetime.utcnow() - password_record.last_updated).days
        
        alert = Alert(
            user_id=user_id,
            alert_type='password_expiry',
            title=f'كلمة مرور {password_record.website_name} تحتاج للتحديث',
            message=f'كلمة المرور لموقع {password_record.website_name} لم يتم تحديثها منذ {days_old} يوم. ننصح بتغييرها لضمان الأمان.',
            severity='medium',
            alert_metadata={
                'website_name': password_record.website_name,
                'days_old': days_old,
                'password_id': password_record.id
            }
        )
        
        db.session.add(alert)

