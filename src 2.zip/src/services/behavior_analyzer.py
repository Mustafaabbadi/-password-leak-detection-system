import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import joblib
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import requests
from src.models.user import db, LoginLog, Alert, User

class BehaviorAnalyzer:
    """محلل السلوك بالذكاء الاصطناعي لاكتشاف النشاط المشبوه"""
    
    def __init__(self):
        self.rf_model = None
        self.isolation_forest = None
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.is_trained = False
        
        # عتبات التحليل
        self.risk_thresholds = {
            'low': 0.3,
            'medium': 0.6,
            'high': 0.8,
            'critical': 0.9
        }
    
    def analyze_login_attempt(self, user_id: int, ip_address: str, 
                            user_agent: str, is_successful: bool = True) -> Dict:
        """تحليل محاولة تسجيل دخول وتقييم مستوى الخطر"""
        
        # الحصول على معلومات الموقع الجغرافي
        location_info = self._get_location_info(ip_address)
        
        # إنشاء سجل تسجيل الدخول
        login_log = LoginLog(
            user_id=user_id,
            ip_address=ip_address,
            user_agent=user_agent,
            location_country=location_info.get('country'),
            location_city=location_info.get('city'),
            is_successful=is_successful
        )
        
        # تحليل السلوك وحساب درجة المخاطر
        risk_analysis = self._calculate_risk_score(user_id, login_log)
        login_log.risk_score = risk_analysis['risk_score']
        login_log.is_suspicious = risk_analysis['is_suspicious']
        
        # حفظ السجل في قاعدة البيانات
        db.session.add(login_log)
        
        # إنشاء تنبيه إذا كان النشاط مشبوهاً
        if risk_analysis['is_suspicious']:
            self._create_suspicious_activity_alert(user_id, login_log, risk_analysis)
        
        db.session.commit()
        
        return {
            'success': True,
            'login_log_id': login_log.id,
            'risk_score': risk_analysis['risk_score'],
            'is_suspicious': risk_analysis['is_suspicious'],
            'risk_factors': risk_analysis['risk_factors'],
            'location': location_info
        }
    
    def _get_location_info(self, ip_address: str) -> Dict:
        """الحصول على معلومات الموقع الجغرافي من عنوان IP"""
        try:
            # استخدام خدمة مجانية للحصول على معلومات الموقع
            response = requests.get(f"http://ip-api.com/json/{ip_address}", timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                if data['status'] == 'success':
                    return {
                        'country': data.get('country', 'غير معروف'),
                        'city': data.get('city', 'غير معروف'),
                        'region': data.get('regionName', 'غير معروف'),
                        'timezone': data.get('timezone', 'غير معروف'),
                        'isp': data.get('isp', 'غير معروف')
                    }
            
            # في حالة فشل الخدمة، نقوم بمحاكاة البيانات
            return self._simulate_location_info(ip_address)
            
        except Exception as e:
            return self._simulate_location_info(ip_address)
    
    def _simulate_location_info(self, ip_address: str) -> Dict:
        """محاكاة معلومات الموقع الجغرافي للأغراض التوضيحية"""
        # محاكاة بسيطة بناءً على عنوان IP
        ip_hash = hash(ip_address) % 10
        
        countries = ['السعودية', 'الإمارات', 'مصر', 'الأردن', 'الكويت', 
                    'قطر', 'البحرين', 'عمان', 'لبنان', 'المغرب']
        cities = ['الرياض', 'دبي', 'القاهرة', 'عمان', 'الكويت',
                 'الدوحة', 'المنامة', 'مسقط', 'بيروت', 'الرباط']
        
        return {
            'country': countries[ip_hash],
            'city': cities[ip_hash],
            'region': 'منطقة تجريبية',
            'timezone': 'Asia/Riyadh',
            'isp': 'مزود خدمة تجريبي'
        }
    
    def _calculate_risk_score(self, user_id: int, current_login: LoginLog) -> Dict:
        """حساب درجة المخاطر للنشاط الحالي"""
        risk_factors = []
        risk_score = 0.0
        
        # الحصول على سجل تسجيل الدخول السابق للمستخدم
        previous_logins = LoginLog.query.filter_by(user_id=user_id)\
            .order_by(LoginLog.login_time.desc()).limit(50).all()
        
        if not previous_logins:
            # مستخدم جديد - مخاطر متوسطة
            risk_score = 0.4
            risk_factors.append("مستخدم جديد - لا يوجد تاريخ سابق")
        else:
            # تحليل الأنماط المختلفة
            risk_score += self._analyze_location_pattern(current_login, previous_logins, risk_factors)
            risk_score += self._analyze_time_pattern(current_login, previous_logins, risk_factors)
            risk_score += self._analyze_device_pattern(current_login, previous_logins, risk_factors)
            risk_score += self._analyze_frequency_pattern(current_login, previous_logins, risk_factors)
        
        # تحليل محاولات فاشلة متتالية
        risk_score += self._analyze_failed_attempts(user_id, risk_factors)
        
        # تطبيق الحد الأقصى والأدنى
        risk_score = max(0.0, min(1.0, risk_score))
        
        # تحديد ما إذا كان النشاط مشبوهاً
        is_suspicious = risk_score >= self.risk_thresholds['medium']
        
        return {
            'risk_score': risk_score,
            'is_suspicious': is_suspicious,
            'risk_factors': risk_factors
        }
    
    def _analyze_location_pattern(self, current_login: LoginLog, 
                                previous_logins: List[LoginLog], 
                                risk_factors: List[str]) -> float:
        """تحليل نمط الموقع الجغرافي"""
        risk_score = 0.0
        
        # الحصول على البلدان المستخدمة سابقاً
        previous_countries = [log.location_country for log in previous_logins 
                            if log.location_country]
        
        if current_login.location_country:
            if current_login.location_country not in previous_countries:
                # دولة جديدة
                risk_score += 0.3
                risk_factors.append(f"تسجيل دخول من دولة جديدة: {current_login.location_country}")
            
            # فحص المسافة الجغرافية (تقريبي)
            if previous_logins and previous_logins[0].location_country:
                if (current_login.location_country != previous_logins[0].location_country and
                    previous_logins[0].login_time > datetime.utcnow() - timedelta(hours=1)):
                    # تغيير سريع في الموقع
                    risk_score += 0.4
                    risk_factors.append("تغيير سريع في الموقع الجغرافي")
        
        return risk_score
    
    def _analyze_time_pattern(self, current_login: LoginLog, 
                            previous_logins: List[LoginLog], 
                            risk_factors: List[str]) -> float:
        """تحليل نمط التوقيت"""
        risk_score = 0.0
        
        # تحليل ساعات النشاط المعتادة
        current_hour = current_login.login_time.hour
        
        # الحصول على ساعات النشاط السابقة
        previous_hours = [log.login_time.hour for log in previous_logins]
        
        if previous_hours:
            # حساب الساعات الأكثر شيوعاً
            hour_counts = {}
            for hour in previous_hours:
                hour_counts[hour] = hour_counts.get(hour, 0) + 1
            
            # إذا كانت الساعة الحالية غير شائعة
            if current_hour not in hour_counts or hour_counts[current_hour] < 2:
                # فحص إذا كانت في ساعات غير عادية (منتصف الليل - الفجر)
                if current_hour >= 0 and current_hour <= 5:
                    risk_score += 0.2
                    risk_factors.append(f"تسجيل دخول في ساعة غير معتادة: {current_hour:02d}:00")
        
        return risk_score
    
    def _analyze_device_pattern(self, current_login: LoginLog, 
                              previous_logins: List[LoginLog], 
                              risk_factors: List[str]) -> float:
        """تحليل نمط الجهاز"""
        risk_score = 0.0
        
        # الحصول على User Agents السابقة
        previous_agents = [log.user_agent for log in previous_logins 
                          if log.user_agent]
        
        if current_login.user_agent:
            if current_login.user_agent not in previous_agents:
                # جهاز أو متصفح جديد
                risk_score += 0.15
                risk_factors.append("تسجيل دخول من جهاز أو متصفح جديد")
        
        return risk_score
    
    def _analyze_frequency_pattern(self, current_login: LoginLog, 
                                 previous_logins: List[LoginLog], 
                                 risk_factors: List[str]) -> float:
        """تحليل نمط تكرار تسجيل الدخول"""
        risk_score = 0.0
        
        # فحص محاولات متكررة في فترة قصيرة
        recent_logins = [log for log in previous_logins 
                        if log.login_time > datetime.utcnow() - timedelta(minutes=30)]
        
        if len(recent_logins) > 5:
            risk_score += 0.3
            risk_factors.append(f"محاولات متكررة: {len(recent_logins)} محاولة في آخر 30 دقيقة")
        
        return risk_score
    
    def _analyze_failed_attempts(self, user_id: int, risk_factors: List[str]) -> float:
        """تحليل محاولات تسجيل الدخول الفاشلة"""
        risk_score = 0.0
        
        # فحص المحاولات الفاشلة في آخر ساعة
        recent_failed = LoginLog.query.filter(
            LoginLog.user_id == user_id,
            LoginLog.is_successful == False,
            LoginLog.login_time > datetime.utcnow() - timedelta(hours=1)
        ).count()
        
        if recent_failed > 3:
            risk_score += 0.4
            risk_factors.append(f"محاولات فاشلة متكررة: {recent_failed} محاولة في آخر ساعة")
        elif recent_failed > 0:
            risk_score += 0.1
            risk_factors.append(f"محاولات فاشلة: {recent_failed} محاولة في آخر ساعة")
        
        return risk_score
    
    def _create_suspicious_activity_alert(self, user_id: int, login_log: LoginLog, 
                                        risk_analysis: Dict):
        """إنشاء تنبيه للنشاط المشبوه"""
        
        # تحديد مستوى الخطورة
        risk_score = risk_analysis['risk_score']
        if risk_score >= self.risk_thresholds['critical']:
            severity = 'critical'
        elif risk_score >= self.risk_thresholds['high']:
            severity = 'high'
        else:
            severity = 'medium'
        
        # إنشاء رسالة التنبيه
        message = f"تم اكتشاف نشاط مشبوه في حسابك.\n\n"
        message += f"تفاصيل النشاط:\n"
        message += f"• عنوان IP: {login_log.ip_address}\n"
        message += f"• الموقع: {login_log.location_city}, {login_log.location_country}\n"
        message += f"• التوقيت: {login_log.login_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        message += f"• درجة المخاطر: {risk_score:.2f}/1.00\n\n"
        
        message += "عوامل الخطر المكتشفة:\n"
        for factor in risk_analysis['risk_factors']:
            message += f"• {factor}\n"
        
        message += "\nالتوصيات:\n"
        message += "• تحقق من أن هذا النشاط مصرح به\n"
        message += "• قم بتغيير كلمة المرور إذا لم تكن أنت من قام بهذا النشاط\n"
        message += "• فعّل المصادقة الثنائية لحماية إضافية\n"
        message += "• راجع الأجهزة المتصلة بحسابك"
        
        alert = Alert(
            user_id=user_id,
            alert_type='suspicious_login',
            title=f'نشاط مشبوه مكتشف - درجة المخاطر: {risk_score:.0%}',
            message=message,
            severity=severity,
            alert_metadata={
                'login_log_id': login_log.id,
                'ip_address': login_log.ip_address,
                'location': f"{login_log.location_city}, {login_log.location_country}",
                'risk_score': risk_score,
                'risk_factors': risk_analysis['risk_factors']
            }
        )
        
        db.session.add(alert)
    
    def train_ml_model(self, user_id: Optional[int] = None) -> Dict:
        """تدريب نموذج التعلم الآلي لتحليل السلوك"""
        try:
            # جمع بيانات التدريب
            query = LoginLog.query
            if user_id:
                query = query.filter_by(user_id=user_id)
            
            login_logs = query.all()
            
            if len(login_logs) < 50:
                return {
                    'success': False,
                    'error': 'بيانات غير كافية للتدريب (يحتاج 50 سجل على الأقل)'
                }
            
            # تحضير البيانات
            df = self._prepare_training_data(login_logs)
            
            # تدريب النموذج
            X = df.drop(['is_suspicious', 'user_id'], axis=1)
            y = df['is_suspicious']
            
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42, stratify=y
            )
            
            # تطبيق التطبيع
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # تدريب Random Forest
            self.rf_model = RandomForestClassifier(
                n_estimators=100,
                random_state=42,
                class_weight='balanced'
            )
            self.rf_model.fit(X_train_scaled, y_train)
            
            # تدريب Isolation Forest للكشف عن الشذوذ
            self.isolation_forest = IsolationForest(
                contamination=0.1,
                random_state=42
            )
            self.isolation_forest.fit(X_train_scaled)
            
            # تقييم النموذج
            y_pred = self.rf_model.predict(X_test_scaled)
            accuracy = accuracy_score(y_test, y_pred)
            
            self.is_trained = True
            
            # حفظ النموذج
            self._save_model()
            
            return {
                'success': True,
                'accuracy': accuracy,
                'training_samples': len(login_logs),
                'test_samples': len(X_test),
                'message': 'تم تدريب النموذج بنجاح'
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'خطأ في تدريب النموذج: {str(e)}'
            }
    
    def _prepare_training_data(self, login_logs: List[LoginLog]) -> pd.DataFrame:
        """تحضير بيانات التدريب"""
        data = []
        
        for log in login_logs:
            # استخراج الميزات من سجل تسجيل الدخول
            features = {
                'user_id': log.user_id,
                'hour': log.login_time.hour,
                'day_of_week': log.login_time.weekday(),
                'is_weekend': 1 if log.login_time.weekday() >= 5 else 0,
                'is_successful': 1 if log.is_successful else 0,
                'risk_score': log.risk_score or 0,
                'is_suspicious': 1 if log.is_suspicious else 0
            }
            
            # ترميز الموقع الجغرافي
            if log.location_country:
                features['country'] = log.location_country
            else:
                features['country'] = 'unknown'
            
            data.append(features)
        
        df = pd.DataFrame(data)
        
        # ترميز المتغيرات الفئوية
        if 'country' in df.columns:
            if 'country' not in self.label_encoders:
                self.label_encoders['country'] = LabelEncoder()
            df['country_encoded'] = self.label_encoders['country'].fit_transform(df['country'])
            df = df.drop('country', axis=1)
        
        return df
    
    def _save_model(self):
        """حفظ النموذج المدرب"""
        try:
            model_data = {
                'rf_model': self.rf_model,
                'isolation_forest': self.isolation_forest,
                'scaler': self.scaler,
                'label_encoders': self.label_encoders,
                'is_trained': self.is_trained
            }
            
            joblib.dump(model_data, 'behavior_model.pkl')
            
        except Exception as e:
            print(f"خطأ في حفظ النموذج: {str(e)}")
    
    def load_model(self) -> bool:
        """تحميل النموذج المحفوظ"""
        try:
            model_data = joblib.load('behavior_model.pkl')
            
            self.rf_model = model_data['rf_model']
            self.isolation_forest = model_data['isolation_forest']
            self.scaler = model_data['scaler']
            self.label_encoders = model_data['label_encoders']
            self.is_trained = model_data['is_trained']
            
            return True
            
        except Exception as e:
            print(f"خطأ في تحميل النموذج: {str(e)}")
            return False
    
    def get_user_behavior_stats(self, user_id: int) -> Dict:
        """إحصائيات سلوك المستخدم"""
        logs = LoginLog.query.filter_by(user_id=user_id).all()
        
        if not logs:
            return {'error': 'لا توجد بيانات للمستخدم'}
        
        total_logins = len(logs)
        successful_logins = len([log for log in logs if log.is_successful])
        suspicious_logins = len([log for log in logs if log.is_suspicious])
        
        # أكثر البلدان استخداماً
        countries = [log.location_country for log in logs if log.location_country]
        country_counts = {}
        for country in countries:
            country_counts[country] = country_counts.get(country, 0) + 1
        
        # أكثر الساعات نشاطاً
        hours = [log.login_time.hour for log in logs]
        hour_counts = {}
        for hour in hours:
            hour_counts[hour] = hour_counts.get(hour, 0) + 1
        
        return {
            'total_logins': total_logins,
            'successful_logins': successful_logins,
            'failed_logins': total_logins - successful_logins,
            'suspicious_logins': suspicious_logins,
            'success_rate': successful_logins / total_logins if total_logins > 0 else 0,
            'most_used_countries': sorted(country_counts.items(), key=lambda x: x[1], reverse=True)[:5],
            'most_active_hours': sorted(hour_counts.items(), key=lambda x: x[1], reverse=True)[:5],
            'average_risk_score': np.mean([log.risk_score or 0 for log in logs])
        }

